
import React, { useState } from 'react';

function BookingForm() {
  const [formData, setFormData] = useState({
    name: '',
    date: '',
    time: '',
    guests: 1
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.date) newErrors.date = 'Date is required';
    if (!formData.time) newErrors.time = 'Time is required';
    if (formData.guests < 1) newErrors.guests = 'At least 1 guest required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
    } else {
      alert('Booking submitted!');
      setErrors({});
    }
  };

  return (
    <form onSubmit={handleSubmit} aria-label="Booking Form">
      <h2>Book a Table</h2>
      <label htmlFor="name">Name</label>
      <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} aria-required="true" />
      {errors.name && <p>{errors.name}</p>}

      <label htmlFor="date">Date</label>
      <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} />
      {errors.date && <p>{errors.date}</p>}

      <label htmlFor="time">Time</label>
      <input type="time" id="time" name="time" value={formData.time} onChange={handleChange} />
      {errors.time && <p>{errors.time}</p>}

      <label htmlFor="guests">Number of Guests</label>
      <input type="number" id="guests" name="guests" min="1" value={formData.guests} onChange={handleChange} />
      {errors.guests && <p>{errors.guests}</p>}

      <button type="submit">Submit</button>
    </form>
  );
}

export default BookingForm;
