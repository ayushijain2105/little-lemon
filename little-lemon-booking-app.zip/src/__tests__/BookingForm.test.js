
import { render, screen } from '@testing-library/react';
import BookingForm from '../components/BookingForm';
import '@testing-library/jest-dom';

test('renders the booking form', () => {
  render(<BookingForm />);
  const heading = screen.getByText(/Book a Table/i);
  expect(heading).toBeInTheDocument();
});
